import makeWASocket, { DisconnectReason, useMultiFileAuthState } from '@whiskeysockets/baileys';
import pino from 'pino';
import qrcode from 'qrcode-terminal';

const logger = pino({ level: 'silent' });
let stopping = false;
let reconnecting = false;

async function startBot() {
  if (reconnecting || stopping) return;
  reconnecting = true;
  try {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const sock = makeWASocket({
      auth: state, logger, printQRInTerminal: false,
      markOnlineOnConnect: false, syncFullHistory: false
    });
    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        console.log('\nScan QR melalui WhatsApp > Perangkat tertaut > Tautkan perangkat:\n');
        qrcode.generate(qr, { small: true });
      }
      if (connection === 'open') console.log('✅ AFRIZALXD terhubung ke WhatsApp.');
      if (connection === 'close') {
        const status = lastDisconnect?.error?.output?.statusCode;
        reconnecting = false;
        if (status === DisconnectReason.loggedOut) {
          stopping = true;
          console.log('Sesi keluar. Hapus folder session dan jalankan ulang untuk login lagi.');
          return;
        }
        console.log('Koneksi terputus. Mencoba kembali dalam 5 detik...');
        setTimeout(startBot, 5000);
      }
    });
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const msg of messages) {
        if (!msg.message || msg.key.fromMe || msg.key.remoteJid === 'status@broadcast') continue;
        const chat = msg.key.remoteJid;
        const body = msg.message.conversation ??
          msg.message.extendedTextMessage?.text ??
          msg.message.imageMessage?.caption ?? '';
        const command = body.trim().toLowerCase();
        try {
          if (command === 'menu') {
            await sock.sendMessage(chat, { text: '╭━━━「 AFRIZALXD 」━━━\n┃ menu\n┃ ping\n┃ info\n╰━━━━━━━━━━━━━━━━' });
          } else if (command === 'ping') {
            await sock.sendMessage(chat, { text: 'Pong! AFRIZALXD aktif.' });
          } else if (command === 'info') {
            await sock.sendMessage(chat, { text: 'AFRIZALXD BAILEYS BOT\nNode.js + Baileys' });
          }
        } catch (error) { console.error('Gagal memproses pesan:', error); }
      }
    });
    reconnecting = false;
  } catch (error) {
    reconnecting = false;
    console.error('Gagal memulai bot:', error);
    setTimeout(startBot, 5000);
  }
}
process.on('SIGINT', () => {
  stopping = true;
  console.log('\nAFRIZALXD dihentikan.');
  process.exit(0);
});
console.log('Memulai AFRIZALXD Baileys...');
startBot();
