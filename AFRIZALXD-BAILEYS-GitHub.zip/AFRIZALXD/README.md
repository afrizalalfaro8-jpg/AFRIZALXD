# AFRIZALXD Baileys Bot

WhatsApp bot sederhana menggunakan Node.js dan Baileys.

## Requirements
- Node.js 20 atau lebih baru
- Termux atau Linux

## Install dan jalankan
```bash
npm install
npm start
```

Saat QR muncul, tautkan perangkat melalui WhatsApp > Perangkat tertaut > Tautkan perangkat.

## Commands
- `menu`
- `ping`
- `info`

Folder `session/` menyimpan data autentikasi. Jangan bagikan atau unggah folder ini ke GitHub.
Gunakan bot secara wajar dan patuhi ketentuan WhatsApp.
