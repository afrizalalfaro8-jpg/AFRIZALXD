# AFRIZALXD

A lightweight, reusable JavaScript utility library for Node.js projects.

- **Repository:** `afrizalxd`
- **Version:** `1.0.0`
- **Runtime:** Node.js 20+
- **Module format:** ES Modules
- **License:** MIT

## Installation

Clone this GitHub repository:

```bash
git clone https://github.com/USERNAME/afrizalxd.git
cd afrizalxd
npm install
```

Replace `USERNAME` with your GitHub username.

If you publish the package to npm under the available name `afrizalxd`, users can install it with:

```bash
npm install afrizalxd
```

## Quick start

```js
import {
  capitalize,
  slugify,
  unique,
  chunk,
  isEmail
} from './src/index.js';

console.log(capitalize('hello'));       // Hello
console.log(slugify('Hello World!'));   // hello-world
console.log(unique([1, 1, 2, 3]));      // [1, 2, 3]
console.log(chunk([1, 2, 3, 4], 2));    // [[1, 2], [3, 4]]
console.log(isEmail('a@b.com'));        // true
```

## API

### Strings
- `capitalize(value)`
- `reverseString(value)`
- `slugify(value)`
- `truncate(value, maxLength, ending = '...')`

### Objects
- `pick(object, keys)`
- `omit(object, keys)`
- `isPlainObject(value)`
- `deepClone(value)`

### Arrays
- `unique(items)`
- `chunk(items, size)`
- `shuffle(items, random = Math.random)`

### Async
- `sleep(milliseconds)`
- `retry(operation, options)`

### Validators
- `isEmail(value)`
- `isURL(value)`
- `isStrongPassword(value)`

## Development

```bash
npm install
npm test
npm run check
```

## GitHub Actions

The workflow in `.github/workflows/ci.yml` runs tests and syntax checks on pushes and pull requests.

## Publishing to npm

1. Check that the package name `afrizalxd` is available on npm.
2. Create an npm account and verify it.
3. Run `npm login`.
4. Run `npm test`.
5. Run `npm publish`.

Do not publish until you have reviewed the package contents and confirmed the package name is available.

## License

MIT. See [LICENSE](./LICENSE).
