import test from 'node:test';
import assert from 'node:assert/strict';
import {
  capitalize, reverseString, slugify, truncate,
  pick, omit, isPlainObject, deepClone,
  unique, chunk, shuffle, isEmail, isURL, isStrongPassword,
  version, libraryName
} from '../src/index.js';

test('package metadata exports', () => {
  assert.equal(libraryName, 'AFRIZALXD');
  assert.equal(version, '1.0.0');
});

test('string helpers', () => {
  assert.equal(capitalize('afrizalxd'), 'Afrizalxd');
  assert.equal(reverseString('hello'), 'olleh');
  assert.equal(slugify('Hello World!'), 'hello-world');
  assert.equal(truncate('abcdefgh', 6), 'abc...');
  assert.throws(() => capitalize(123), TypeError);
});

test('object helpers', () => {
  const source = { a: 1, b: 2, c: 3 };
  assert.deepEqual(pick(source, ['a', 'c']), { a: 1, c: 3 });
  assert.deepEqual(omit(source, ['b']), { a: 1, c: 3 });
  assert.equal(isPlainObject(source), true);
  assert.equal(isPlainObject([]), false);
  assert.deepEqual(deepClone(source), source);
});

test('array helpers', () => {
  assert.deepEqual(unique([1, 1, 2]), [1, 2]);
  assert.deepEqual(chunk([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]]);
  assert.deepEqual(shuffle([1, 2, 3], () => 0), [2, 3, 1]);
  assert.throws(() => chunk([], 0), TypeError);
});

test('validators', () => {
  assert.equal(isEmail('hello@example.com'), true);
  assert.equal(isEmail('not-an-email'), false);
  assert.equal(isURL('https://example.com'), true);
  assert.equal(isURL('javascript:alert(1)'), false);
  assert.equal(isStrongPassword('GoodPass1!'), true);
  assert.equal(isStrongPassword('weak'), false);
});
