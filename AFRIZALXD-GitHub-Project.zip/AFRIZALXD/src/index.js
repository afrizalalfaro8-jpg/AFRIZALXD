/**
 * AFRIZALXD - lightweight JavaScript utilities.
 * Requires Node.js 20+.
 */
export { capitalize, reverseString, slugify, truncate } from './strings.js';
export { pick, omit, isPlainObject, deepClone } from './objects.js';
export { unique, chunk, shuffle } from './arrays.js';
export { sleep, retry } from './async.js';
export { isEmail, isURL, isStrongPassword } from './validators.js';

export const version = '1.0.0';
export const libraryName = 'AFRIZALXD';
