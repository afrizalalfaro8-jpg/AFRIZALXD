/** Return a new object containing only the requested own properties. */
export function pick(object, keys) {
  assertObject(object);
  if (!Array.isArray(keys)) throw new TypeError('keys must be an array');
  return Object.fromEntries(
    keys.filter((key) => Object.hasOwn(object, key)).map((key) => [key, object[key]])
  );
}

/** Return a new object without the requested own properties. */
export function omit(object, keys) {
  assertObject(object);
  if (!Array.isArray(keys)) throw new TypeError('keys must be an array');
  const excluded = new Set(keys);
  return Object.fromEntries(
    Object.entries(object).filter(([key]) => !excluded.has(key))
  );
}

/** Check whether a value is a plain object. */
export function isPlainObject(value) {
  if (value === null || typeof value !== 'object') return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

/** Clone JSON-compatible data. */
export function deepClone(value) {
  return structuredClone(value);
}

function assertObject(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('value must be an object');
  }
}
