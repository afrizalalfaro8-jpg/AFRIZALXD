/** Return an array containing each value once, preserving first occurrence. */
export function unique(items) {
  if (!Array.isArray(items)) throw new TypeError('items must be an array');
  return [...new Set(items)];
}

/** Split an array into chunks of the given positive size. */
export function chunk(items, size) {
  if (!Array.isArray(items)) throw new TypeError('items must be an array');
  if (!Number.isInteger(size) || size < 1) {
    throw new TypeError('size must be a positive integer');
  }
  const result = [];
  for (let index = 0; index < items.length; index += size) {
    result.push(items.slice(index, index + size));
  }
  return result;
}

/** Return a shuffled copy using Fisher-Yates. */
export function shuffle(items, random = Math.random) {
  if (!Array.isArray(items)) throw new TypeError('items must be an array');
  if (typeof random !== 'function') throw new TypeError('random must be a function');
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(random() * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}
