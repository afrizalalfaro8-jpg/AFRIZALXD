/** Wait for a number of milliseconds. */
export function sleep(milliseconds) {
  if (!Number.isFinite(milliseconds) || milliseconds < 0) {
    throw new TypeError('milliseconds must be a non-negative number');
  }
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

/**
 * Retry an async operation.
 * options: { retries = 3, delay = 250, factor = 2, shouldRetry = () => true }
 */
export async function retry(operation, options = {}) {
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  const {
    retries = 3,
    delay = 250,
    factor = 2,
    shouldRetry = () => true
  } = options;

  if (!Number.isInteger(retries) || retries < 0) throw new TypeError('retries must be a non-negative integer');
  if (!Number.isFinite(delay) || delay < 0) throw new TypeError('delay must be non-negative');
  if (!Number.isFinite(factor) || factor < 1) throw new TypeError('factor must be at least 1');
  if (typeof shouldRetry !== 'function') throw new TypeError('shouldRetry must be a function');

  let attempt = 0;
  while (true) {
    try {
      return await operation(attempt);
    } catch (error) {
      if (attempt >= retries || !shouldRetry(error, attempt)) throw error;
      await sleep(delay * factor ** attempt);
      attempt += 1;
    }
  }
}
