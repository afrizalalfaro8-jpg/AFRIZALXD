/** Basic email format check; not a substitute for email verification. */
export function isEmail(value) {
  return typeof value === 'string' &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

/** Check whether a string is an absolute HTTP(S) URL. */
export function isURL(value) {
  if (typeof value !== 'string') return false;
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

/** Basic password-strength check: 8+ chars, upper, lower, digit, symbol. */
export function isStrongPassword(value) {
  return typeof value === 'string' &&
    value.length >= 8 &&
    /[a-z]/.test(value) &&
    /[A-Z]/.test(value) &&
    /\d/.test(value) &&
    /[^A-Za-z0-9]/.test(value);
}
