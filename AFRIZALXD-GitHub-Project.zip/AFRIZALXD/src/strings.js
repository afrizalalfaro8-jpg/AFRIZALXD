/** Capitalize the first character of a string. */
export function capitalize(value) {
  assertString(value);
  if (value.length === 0) return '';
  return value[0].toLocaleUpperCase() + value.slice(1);
}

/** Reverse a string by Unicode code points. */
export function reverseString(value) {
  assertString(value);
  return Array.from(value).reverse().join('');
}

/** Convert text into a URL-friendly slug. */
export function slugify(value) {
  assertString(value);
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/** Truncate a string to maxLength, optionally adding an ending. */
export function truncate(value, maxLength, ending = '...') {
  assertString(value);
  if (!Number.isInteger(maxLength) || maxLength < 0) {
    throw new TypeError('maxLength must be a non-negative integer');
  }
  assertString(ending, 'ending');
  if (value.length <= maxLength) return value;
  if (maxLength <= ending.length) return ending.slice(0, maxLength);
  return value.slice(0, maxLength - ending.length) + ending;
}

function assertString(value, name = 'value') {
  if (typeof value !== 'string') throw new TypeError(`${name} must be a string`);
}
